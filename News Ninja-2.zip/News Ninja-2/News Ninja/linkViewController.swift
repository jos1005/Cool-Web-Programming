//
//  linkViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/29/23.
//

import UIKit
import WebKit
import CoreData

class linkViewController: UIViewController {
    
    var linkCountry = -1
    var linkNews = ""
    
    let webView: WKWebView = {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences = prefs
        let webView = WKWebView(frame: .zero, configuration: configuration)
        return webView
    }()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(webView)
        
        guard let url = URL(string: linkNews) else {
            return
        }
        
        webView.load(URLRequest(url: url))
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.webView.evaluateJavaScript("document.body.innerHTML") {
                result, error in
                guard let html = result as? String, error == nil else {
                    return
                }
            }
        }
        incrementScoreCoreData(attribute: countrycode2[linkCountry])
        incrementScoreCoreData(attribute: "totpoints")
        updateStatus()
        print(checkAttributeValue(attributeName: "status"))
    }
    
    // for web view
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }

}
