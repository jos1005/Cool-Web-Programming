//
//  readingViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/18/23.
//

import UIKit
import Foundation

class readingViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate {

    // ui elements used and other variables
    
    var news_articles : [(String, String)] = []
    
    @IBOutlet weak var tableView: UITableView!
    let textCellIdentifier = "cell"
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var loader: UIButton!
    
    @IBOutlet weak var picker: UIPickerView!
    var pickerCountry = ""
    
    @IBOutlet weak var scroller: UIScrollView!
    
    @IBOutlet weak var viewz: UIView!
    
    // constraints to be modified
    
    @IBOutlet weak var loaderUp: NSLayoutConstraint!
    @IBOutlet weak var loaderDown: NSLayoutConstraint!
    
    var side = 0
    var country = "Afghanistan"
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        
        picker.delegate = self
        picker.dataSource = self
        let newHeight: CGFloat = 200.0
        picker.frame.size.height = newHeight
        
        tableView.isScrollEnabled = false
        tableView.delegate = self
        tableView.dataSource = self
        
        loadInitialNews()
        
        scroller.delegate = self
        
        viewz.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        viewz.layer.cornerRadius = 10.0
        viewz.layer.borderWidth = 2.0
        viewz.layer.borderColor = UIColor.black.cgColor
    
    }
    
    // standard functions for pickers 1/5
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // 2/5
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countries.count
    }
    
    // 3/5
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row]
    }
    
    // 4/5
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickerCountry = countries[row]
    }

    // 5/5
    func getPickerValue() -> String {
        return pickerCountry
    }

    
    // for segmented view loading
    @IBAction func segmentedValueChange(_ sender: Any) {
    
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            side = 0
            picker.isHidden = false
            picker.isUserInteractionEnabled = true
            loaderUp.constant += 200
            loaderDown.constant += 200
            viewz.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
            
        case 1:
            side = 1
            picker.isHidden = true
            picker.isUserInteractionEnabled = false
            
            loaderUp.constant -= 200
            loaderDown.constant -= 200
            viewz.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
           
        default:
            break
        }
    }
    
    // individual article
    struct NewsArticle: Codable {
        let title: String
        let url: String
    }
    
    // list of articles
    struct FetchNewsResponse: Codable {
        let articles: [NewsArticle]
    }
    
    // function for using the API and retrieving key pair values
    func getNews(q: String, completion: @escaping ([(String, String)]) -> Void) {
        
        let apiKey = "4720805739df4e56bbdda073686e2f10"
        let apiURL = "http://newsapi.org/v2/everything?q=\(q)&pageSize=100&language=en&apiKey=\(apiKey)"
        
        guard let url = URL(string: apiURL) else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                let decoder = JSONDecoder()
                let newsResponse = try decoder.decode(FetchNewsResponse.self, from: data)

                let articles = newsResponse.articles
                let result = articles.map { article in
                    return (article.title, article.url)
                }

                completion(result)
            } catch {
                print("Error decoding JSON: \(error.localizedDescription)")
            }
        }

        task.resume()
    }
    
    // loads data for table view on button press
    func loadNews(){
        if side == 1 {
            
            var countCountries = countries.count
            var countrySelectedIdx = Int.random(in: 0..<countCountries)
            var countrySelected = countries[countrySelectedIdx]
            print(countrySelected)
            
            country = countrySelected
            getNews(q: countrySelected) { news in
                self.news_articles = news
                print(self.news_articles)
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        } else {
            
            let countrySelected = getPickerValue()
            print(countrySelected)
            
            country = countrySelected
            getNews(q: countrySelected) { news in
                self.news_articles = news
                print(self.news_articles)
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    // loads news on viewDidLoad()
    func loadInitialNews(){
            
        getNews(q: "Afghanistan") { news in
            self.news_articles = news
            print(self.news_articles)
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    // for loading data when button is pressed
    @IBAction func loadIt(_ sender: Any) {
        loadNews()
    }
    
    // functions for loading up tables 1/2
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return news_articles.count
    }
    
    // 2/2
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath as IndexPath)
        
        let row = indexPath.row
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = news_articles[row].0
    
        return cell
    }
    
    // segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "link",
           let destination = segue.destination as? linkViewController,
           let index = tableView.indexPathForSelectedRow?.row
        {
            print(country)
            
            destination.linkCountry = countries.firstIndex(of: country)!
            destination.linkNews = news_articles[index].1
        }
    }
}
