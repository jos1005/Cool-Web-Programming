//
//  Core Data protocols.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/18/23.
//

import Foundation
import CoreData

func saveContext () {
    if context.hasChanges {
        do {
            try context.save()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
}

    public func createAccount() -> NSManagedObject? {
        let account = NSEntityDescription.insertNewObject(forEntityName: "Accountz", into: context)
        saveContext()
        return account
    }

    // store anything into Core Data
public func storeToCoreData(account: NSManagedObject, key: String, info: Any){
    account.setValue(info, forKey: key)
    saveContext()
}

func getAccountByName(name: String) -> Accountz? {
    let fetchRequest: NSFetchRequest<Accountz> = Accountz.fetchRequest()
    fetchRequest.predicate = NSPredicate(format: "email == %@", name)

    do {
        let accounts = try context.fetch(fetchRequest)
        return accounts.first
    } catch {
        print("Error fetching account by name: \(error)")
        return nil
    }
}

public func checkAttributeValue2(attributeName: String) -> String {
        
    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Accountz")
    
    let predicate = NSPredicate(format: "email == %@", globalUsername)
    fetchRequest.predicate = predicate

    do {
        let results = try context.fetch(fetchRequest) as! [NSManagedObject]
    
        for result in results {
            if let attributeValue = result.value(forKey: attributeName) {
                        
                if let stringValue = attributeValue as? String {
                    print("Attribute '\(attributeName)' value for email '\(globalUsername)': \(stringValue)")
                    return stringValue
                } else {
                    print("Attribute '\(attributeName)' value is not a String. Type: \(type(of: attributeValue))")
                }
            } else {
                print("No value found for attribute '\(attributeName)' and email '\(globalUsername)'.")
            }
        }
    } catch {
        print("Error fetching entities: \(error.localizedDescription)")
    }
    return "Not found"
}

public func checkAttributeValue(attributeName: String) -> Int {
        
    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Accountz")
    
    let predicate = NSPredicate(format: "email == %@", globalUsername)
    fetchRequest.predicate = predicate

    do {
        let results = try context.fetch(fetchRequest) as! [NSManagedObject]
    
        for result in results {
            if let attributeValue = result.value(forKey: attributeName) {
                        
                if let stringValue = attributeValue as? Int {
                    print("Attribute '\(attributeName)' value for email '\(globalUsername)': \(stringValue)")
                    return stringValue
                } else {
                    print("Attribute '\(attributeName)' value is not an Int. Type: \(type(of: attributeValue))")
                }
            } else {
                print("No value found for attribute '\(attributeName)' and email '\(globalUsername)'.")
            }
        }
    } catch {
        print("Error fetching entities: \(error.localizedDescription)")
    }
    return 0
}

// increases the score of both country points and total points
public func incrementScoreCoreData(attribute: String) {

    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Accountz")

    let predicate = NSPredicate(format: "email == %@", globalUsername)
    fetchRequest.predicate = predicate

    do {
        let results = try context.fetch(fetchRequest) as! [NSManagedObject]

        for existingAccount in results {
            // Increment the value of attribute country by 1
            if let currentValue = existingAccount.value(forKey: attribute) as? Int {
                existingAccount.setValue(currentValue + 1, forKey: attribute)
                saveContext()

                
            } else {
                print("Value for attribute \(attribute) is not an integer. Increment operation not performed.")
            }
        }

        print("Value for attribute 'totalpoints' incremented for all records successfully.")
    } catch {
        print("Error incrementing value: \(error.localizedDescription)")
    }
}

public func updateStatus(){
    
    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Accountz")

    let predicate = NSPredicate(format: "email == %@", globalUsername)
    fetchRequest.predicate = predicate

    do {
        let results = try context.fetch(fetchRequest) as! [NSManagedObject]
        
        for existingAccount in results {
            
            var pointsEarned = existingAccount.value(forKey: "totpoints")
            
            for (tier, range) in tiersAndPoints {
                
                if range.contains((pointsEarned as? Int)!) {
                    print("amoxicilin")
                    print(pointsEarned!, tier)
                    existingAccount.setValue(tier, forKey: "status")
                    saveContext()
                }
            }
        }

        print("success checking and/or updating status")
    } catch {
        print("Error updating value: \(error.localizedDescription)")
    }
    
}

// clear data
func clearCoreData() {
    // erase everything currently in Core Data
    
    let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Accountz")
    var fetchedResults:[NSManagedObject]
    
    do {
        try fetchedResults = context.fetch(request) as! [NSManagedObject]
    
        if fetchedResults.count > 0 {
            for result in fetchedResults {
                context.delete(result)
            }
        }
        saveContext()
    } catch {
        print("Error occurred while clearing data")
        abort()
    }
}
