//
//  settingzViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 12/1/23.
//

import UIKit

class settingzViewController: UIViewController {
    
    
    @IBOutlet weak var setting: UIView!
    @IBOutlet weak var switcher: UISwitch!
    @IBOutlet weak var fsizelabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        setting.layer.cornerRadius = 10.0
        setting.layer.borderWidth = 2.0
        setting.layer.borderColor = UIColor.black.cgColor
        setting.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        
        let labelArray = [fsizelabel!]
        changeFontSize(elementArray: labelArray)
        
        let switchState = UserDefaults.standard.bool(forKey: "SwitchState")
        switcher.isOn = switchState
        
        if fontMode == 0 {
            switcher.isOn = false
        } else {
            switcher.isOn = true
        }
    }
    
    // changes font size
    @IBAction func switchDidChange(_ sender: UISwitch){
        if sender.isOn {
            fontMode = 1
        } else {
            fontMode = 0
        }
        changeFontSize(elementArray: [fsizelabel!])
    }
}
