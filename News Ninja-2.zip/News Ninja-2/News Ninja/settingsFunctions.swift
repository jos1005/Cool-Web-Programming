//
//  settingsFunctions.swift
//  News Ninja
//
//  Created by Jose Ruiz on 12/4/23.
//

import Foundation
import UIKit

// change font size
func changeFontSize(elementArray: [Any]){
    var size = 0
    if fontMode == 0 {
        size = 23
    } else {
        size = 26
    }
    
    for element in elementArray {
        if let label = element as? UILabel {
            label.font = label.font.withSize(CGFloat(size))
        } else if let textField = element as? UITextField {
            textField.font = textField.font?.withSize(CGFloat(size))
        }
    }
}
