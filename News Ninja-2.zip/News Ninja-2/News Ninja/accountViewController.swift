//
//  accountViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/30/23.
//

import UIKit

class accountViewController: UIViewController {

    @IBOutlet weak var info: UIView!
    @IBOutlet weak var usernamelbl: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var memberSince: UILabel!
    @IBOutlet weak var ttlpoins: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        info.layer.cornerRadius = 10.0
        info.layer.borderWidth = 2.0
        info.layer.borderColor = UIColor.black.cgColor
        info.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        usernamelbl.text = "username: \(checkAttributeValue2(attributeName: "username"))"
        status.text = "status: \(checkAttributeValue2(attributeName: "status"))"
        memberSince.text = "member since: \(checkAttributeValue2(attributeName: "membersince"))"
        ttlpoins.text = "total points: \(String(checkAttributeValue(attributeName: "totpoints")))"
        changeFontSize(elementArray: [usernamelbl!, status!, memberSince!, ttlpoins!])
        
    }
    
}
