//
//  ViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/17/23.
//

import UIKit
import FirebaseAuth
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext
public var globalUsername : String = ""

class ViewController: UIViewController {
    
    
    @IBOutlet weak var signUp: UILabel!
    @IBOutlet weak var emailText: UILabel!
    @IBOutlet weak var passwordText: UILabel!
   
    @IBOutlet weak var usernameL: UITextField!
    @IBOutlet weak var passwordL: UITextField!
    @IBOutlet weak var errorLabelL: UILabel!
    @IBOutlet weak var info: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        info.layer.cornerRadius = 10.0
        info.layer.borderWidth = 2.0
        info.layer.borderColor = UIColor.black.cgColor
        info.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        updateStatus()
        
        changeFontSize(elementArray: [signUp!, passwordText!, emailText!, errorLabelL!])
        changeFontSize(elementArray: [usernameL!, passwordL!])
        
    }
    
    // verifies log in
    @IBAction func login(_ sender: Any) {
    
        Auth.auth().signIn(withEmail: usernameL.text!, password: passwordL.text!){
            (authResult, error) in
                if let error = error as NSError? {
                    self.errorLabelL.text = "whoops! looks like the email and/or password are incorrect"
                } else {
                    globalUsername =  self.usernameL.text!
                    self.performSegue(withIdentifier: "loginToMap", sender: nil)
                }
        }
    }
}
