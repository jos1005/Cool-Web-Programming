//
//  forBackButton.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/17/23.
//

import UIKit

class forBackButton: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
    }


}
