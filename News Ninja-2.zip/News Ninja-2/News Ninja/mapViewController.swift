//
//  mapViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/17/23.
//

import UIKit
import MapKit

class mapViewController: UIViewController {
    
    
    @IBOutlet weak var pointss: UIView!
    @IBOutlet weak var worldMap: MKMapView!
    @IBOutlet weak var countryChosen: UILabel!
    @IBOutlet weak var countryPoints: UILabel!
    @IBOutlet weak var totalPoints: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        pointss.layer.cornerRadius = 10.0
        pointss.layer.borderWidth = 2.0
        pointss.layer.borderColor = UIColor.black.cgColor
        pointss.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gestureRecognizer:)))
        worldMap.addGestureRecognizer(tapGesture)
        worldMap.mapType = .standard
        
        let totPoints = String(checkAttributeValue(attributeName: "totpoints"))
        totalPoints.text = "Global points: \(totPoints)"
        
        changeFontSize(elementArray: [countryChosen!, countryPoints!, totalPoints!])
        
    }
    
    // find country selected
    @IBAction func handleTap(gestureRecognizer: UITapGestureRecognizer){
        
    let annotationsToRemove = worldMap.annotations.filter { $0 !== worldMap.userLocation }
        worldMap.removeAnnotations(annotationsToRemove)
        
        let location = gestureRecognizer.location(in: worldMap)
        let coordinate = worldMap.convert(location, toCoordinateFrom: worldMap)
        let tappedLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)

        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(tappedLocation) { (placemarks, error) in
            if let error = error {
                print("Reverse geocoding failed with error: \(error.localizedDescription)")
                return
            }

            if let firstPlacemark = placemarks?.first {
                if let country1 = firstPlacemark.country {
                    self.countryChosen.text = "Country: \(country1)"
                    var index = countries.firstIndex(of: country1)!
                    var country2 = countrycode2[index]
                    
                    var countryScore = String(checkAttributeValue(attributeName: country2))
                    var totalScore = String(checkAttributeValue(attributeName: "totpoints"))
                    
                    self.countryPoints.text = "Points: \(String(countryScore))"
                    self.totalPoints.text = "Global points: \(String(totalScore))"
                }
            }
        }
        
        let customAnnotation = MKPointAnnotation()
        customAnnotation.coordinate = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
        worldMap.addAnnotation(customAnnotation)
    }
    
}
