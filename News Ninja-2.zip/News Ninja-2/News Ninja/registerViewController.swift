//
//  registerViewController.swift
//  News Ninja
//
//  Created by Jose Ruiz on 11/17/23.
//

import UIKit
import FirebaseAuth
import CoreData
import Foundation

class registerViewController: UIViewController {

    
    @IBOutlet weak var usernameR: UITextField!
    @IBOutlet weak var emailR: UITextField!
    @IBOutlet weak var passwordR: UITextField!
    
    @IBOutlet weak var cuser: UILabel!
    @IBOutlet weak var elabel: UILabel!
    @IBOutlet weak var ulabel: UILabel!
    @IBOutlet weak var errorLabelR: UILabel!
    
    @IBOutlet weak var warning: UIView!
    @IBOutlet weak var info: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        info.layer.cornerRadius = 10.0
        info.layer.borderWidth = 2.0
        info.layer.borderColor = UIColor.black.cgColor
        info.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
        warning.backgroundColor = UIColor(red: 152/255.0, green: 80/255.0, blue: 209/255.0, alpha: 1.0)
        
        changeFontSize(elementArray: [usernameR!, emailR!, passwordR!])
        changeFontSize(elementArray: [cuser!, elabel!, ulabel!, errorLabelR!])
        
    }
    
    // verifies registration
    @IBAction func register(_ sender: Any) {
        if usernameR.text != "" && emailR.text != "" && passwordR.text != "" {
            
            Auth.auth().createUser(withEmail: emailR.text!, password: passwordR.text!){
                    (authResult, error) in
                    if let error = error as NSError? {
                        
                        self.warning.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
                        self.errorLabelR.text = "\(error.localizedDescription)"
                        
                    } else {
                        
                        globalUsername = self.emailR.text!
                        var account = createAccount()
                        storeToCoreData(account: account!, key: "username", info: self.usernameR.text!)
                        storeToCoreData(account: account!, key: "email", info: globalUsername)
                        storeToCoreData(account: account!, key: "status", info: "Journalism Freshman")
                        
                        let currentDate = Date()
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "MM-dd-yyyy"
                        let formattedDate = dateFormatter.string(from: currentDate)
                        storeToCoreData(account: account!, key: "membersince", info: formattedDate)
                        
                        self.performSegue(withIdentifier: "registerToMap", sender: nil)
                    }
                }
        } else {
            
            warning.layer.cornerRadius = 10.0
            warning.layer.borderWidth = 2.0
            warning.layer.borderColor = UIColor.black.cgColor
            warning.backgroundColor = UIColor(red: 255/255.0, green: 221/255.0, blue: 29/255.0, alpha: 1.0)
            
            errorLabelR.text = "make sure to fill in all fields!"
        }
    }
    
}
