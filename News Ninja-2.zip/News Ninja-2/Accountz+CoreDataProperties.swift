//
//  Accountz+CoreDataProperties.swift
//  News Ninja
//
//  Created by Jose Ruiz on 12/1/23.
//
//

import Foundation
import CoreData


extension Accountz {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Accountz> {
        return NSFetchRequest<Accountz>(entityName: "Accountz")
    }

    @NSManaged public var afghanistan: Int16
    @NSManaged public var albania: Int16
    @NSManaged public var algeria: Int16
    @NSManaged public var andorra: Int16
    @NSManaged public var angola: Int16
    @NSManaged public var argentina: Int16
    @NSManaged public var armenia: Int16
    @NSManaged public var australia: Int16
    @NSManaged public var austria: Int16
    @NSManaged public var azerbaijan: Int16
    @NSManaged public var bahamas: Int16
    @NSManaged public var bahrain: Int16
    @NSManaged public var bangladesh: Int16
    @NSManaged public var barbados: Int16
    @NSManaged public var belarus: Int16
    @NSManaged public var belgium: Int16
    @NSManaged public var belize: Int16
    @NSManaged public var benin: Int16
    @NSManaged public var bhutan: Int16
    @NSManaged public var bolivia: Int16
    @NSManaged public var bosniaherzegovina: Int16
    @NSManaged public var botswana: Int16
    @NSManaged public var brazil: Int16
    @NSManaged public var brunei: Int16
    @NSManaged public var bulgaria: Int16
    @NSManaged public var burkina: Int16
    @NSManaged public var burundi: Int16
    @NSManaged public var cambodia: Int16
    @NSManaged public var cameroon: Int16
    @NSManaged public var canada: Int16
    @NSManaged public var capeverde: Int16
    @NSManaged public var centralafricanrepublic: Int16
    @NSManaged public var chad: Int16
    @NSManaged public var chile: Int16
    @NSManaged public var china: Int16
    @NSManaged public var colombia: Int16
    @NSManaged public var comoros: Int16
    @NSManaged public var costarica: Int16
    @NSManaged public var cotedvoire: Int16
    @NSManaged public var croatia: Int16
    @NSManaged public var cuba: Int16
    @NSManaged public var cyprus: Int16
    @NSManaged public var czechia: Int16
    @NSManaged public var democraticrepublicofcongo: Int16
    @NSManaged public var denmark: Int16
    @NSManaged public var djibouti: Int16
    @NSManaged public var dominica: Int16
    @NSManaged public var dominicanrepublic: Int16
    @NSManaged public var easttimor: Int16
    @NSManaged public var ecuador: Int16
    @NSManaged public var egypt: Int16
    @NSManaged public var elsalvador: Int16
    @NSManaged public var email: String?
    @NSManaged public var equatorialguinea: Int16
    @NSManaged public var eritrea: Int16
    @NSManaged public var estonia: Int16
    @NSManaged public var ethiopia: Int16
    @NSManaged public var fiji: Int16
    @NSManaged public var finland: Int16
    @NSManaged public var france: Int16
    @NSManaged public var gabon: Int16
    @NSManaged public var gambia: Int16
    @NSManaged public var georgia: Int16
    @NSManaged public var germany: Int16
    @NSManaged public var ghana: Int16
    @NSManaged public var greece: Int16
    @NSManaged public var grenada: Int16
    @NSManaged public var guatemala: Int16
    @NSManaged public var guinea: Int16
    @NSManaged public var guineabissau: Int16
    @NSManaged public var guyana: Int16
    @NSManaged public var haiti: Int16
    @NSManaged public var honduras: Int16
    @NSManaged public var hungary: Int16
    @NSManaged public var iceland: Int16
    @NSManaged public var india: Int16
    @NSManaged public var indonesia: Int16
    @NSManaged public var iran: Int16
    @NSManaged public var iraq: Int16
    @NSManaged public var ireland: Int16
    @NSManaged public var israel: Int16
    @NSManaged public var italy: Int16
    @NSManaged public var jamaica: Int16
    @NSManaged public var japan: Int16
    @NSManaged public var jordan: Int16
    @NSManaged public var kazakhstan: Int16
    @NSManaged public var kenya: Int16
    @NSManaged public var kiribati: Int16
    @NSManaged public var kosovo: Int16
    @NSManaged public var kuwait: Int16
    @NSManaged public var kyrgystan: Int16
    @NSManaged public var laos: Int16
    @NSManaged public var latvia: Int16
    @NSManaged public var lebanon: Int16
    @NSManaged public var lesotho: Int16
    @NSManaged public var level: Int16
    @NSManaged public var libya: Int16
    @NSManaged public var liechtenstein: Int16
    @NSManaged public var lithuania: Int16
    @NSManaged public var liveria: Int16
    @NSManaged public var luxembourg: Int16
    @NSManaged public var madagascar: Int16
    @NSManaged public var malawi: Int16
    @NSManaged public var malaysia: Int16
    @NSManaged public var maldives: Int16
    @NSManaged public var mali: Int16
    @NSManaged public var malta: Int16
    @NSManaged public var marshallislands: Int16
    @NSManaged public var mauritania: Int16
    @NSManaged public var mauritius: Int16
    @NSManaged public var membersince: String?
    @NSManaged public var mexico: Int16
    @NSManaged public var micronesia: Int16
    @NSManaged public var moldova: Int16
    @NSManaged public var monaco: Int16
    @NSManaged public var mongolia: Int16
    @NSManaged public var montenegro: Int16
    @NSManaged public var morocco: Int16
    @NSManaged public var mozambique: Int16
    @NSManaged public var myanmar: Int16
    @NSManaged public var namibia: Int16
    @NSManaged public var nauru: Int16
    @NSManaged public var nepa: Int16
    @NSManaged public var netherlands: Int16
    @NSManaged public var newzealand: Int16
    @NSManaged public var nicaragua: Int16
    @NSManaged public var niger: Int16
    @NSManaged public var nigeria: Int16
    @NSManaged public var northkorea: Int16
    @NSManaged public var northmacedonia: Int16
    @NSManaged public var norway: Int16
    @NSManaged public var oman: Int16
    @NSManaged public var pakistan: Int16
    @NSManaged public var palau: Int16
    @NSManaged public var panama: Int16
    @NSManaged public var papuanewguinea: Int16
    @NSManaged public var paraguay: Int16
    @NSManaged public var peru: Int16
    @NSManaged public var philippines: Int16
    @NSManaged public var poland: Int16
    @NSManaged public var portugal: Int16
    @NSManaged public var qatar: Int16
    @NSManaged public var romania: Int16
    @NSManaged public var russia: Int16
    @NSManaged public var rwanda: Int16
    @NSManaged public var saintlucia: Int16
    @NSManaged public var saintskittsandnevis: Int16
    @NSManaged public var saintvincentandthegrenadines: Int16
    @NSManaged public var samoa: Int16
    @NSManaged public var sanmarino: Int16
    @NSManaged public var saotomeandprincipe: Int16
    @NSManaged public var saudiarabia: Int16
    @NSManaged public var senegal: Int16
    @NSManaged public var serbia: Int16
    @NSManaged public var seychelles: Int16
    @NSManaged public var sierraleone: Int16
    @NSManaged public var singapore: Int16
    @NSManaged public var slovakia: Int16
    @NSManaged public var slovenia: Int16
    @NSManaged public var solomonislands: Int16
    @NSManaged public var somalia: Int16
    @NSManaged public var southafrica: Int16
    @NSManaged public var southkorea: Int16
    @NSManaged public var southsudan: Int16
    @NSManaged public var spain: Int16
    @NSManaged public var srilanka: Int16
    @NSManaged public var sudan: Int16
    @NSManaged public var suriname: Int16
    @NSManaged public var swaziland: Int16
    @NSManaged public var sweden: Int16
    @NSManaged public var switzerland: Int16
    @NSManaged public var syria: Int16
    @NSManaged public var taiwan: Int16
    @NSManaged public var tajikistan: Int16
    @NSManaged public var tanzania: Int16
    @NSManaged public var thailand: Int16
    @NSManaged public var togo: Int16
    @NSManaged public var tonga: Int16
    @NSManaged public var totpoints: Int16
    @NSManaged public var trinidadandtobago: Int16
    @NSManaged public var tunisia: Int16
    @NSManaged public var turkey: Int16
    @NSManaged public var turkmenistan: Int16
    @NSManaged public var tuvalu: Int16
    @NSManaged public var uganda: Int16
    @NSManaged public var ukraine: Int16
    @NSManaged public var unitedarabemirates: Int16
    @NSManaged public var unitedkingdom: Int16
    @NSManaged public var unitedstates: Int16
    @NSManaged public var uruguay: Int16
    @NSManaged public var username: String?
    @NSManaged public var uzbekistan: Int16
    @NSManaged public var vanuatu: Int16
    @NSManaged public var vaticancity: Int16
    @NSManaged public var venezuela: Int16
    @NSManaged public var vietnam: Int16
    @NSManaged public var yemen: Int16
    @NSManaged public var zambia: Int16
    @NSManaged public var zimbabwe: Int16

}

extension Accountz : Identifiable {

}
