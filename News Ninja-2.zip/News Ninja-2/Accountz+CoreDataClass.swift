//
//  Accountz+CoreDataClass.swift
//  News Ninja
//
//  Created by Jose Ruiz on 12/1/23.
//
//

import Foundation
import CoreData


public class Accountz: NSManagedObject {

}
